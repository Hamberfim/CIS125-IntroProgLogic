3a.)
Start
    StepA
    if B True
        StepC
        StepA
Stop

3b.)
Start
    StepD
    if E True
        StepH
        StepI
    else
        StepF
        if G True
            StepI
Stop

3c.)
Start
    StepK
    if L True
        StepP
        if Q True
            StepP
        else
            StepR
    else
        StepM
        StepN
    if Q True
        StepR
Stop

3d.)
Start
    StepS
    if T True:
        StepY
        if Z True:
            StepV
            if W True:
                StepA
            else:
                StepX
        else:
            StepA
    else:
        StepU
        StepV
        if W True:
            StepA
        else:
            StepX
Stop

3e.)
Start
    if B True:
        StepG
        if H True:
            StepD
            if E True:
                StepI
                StepD
            else:
                StepF
        else:
            StepI
            StepG
    else:
        StepC
        StepD
        if E True:
            StepI
            StepD
        else:
            StepF
Stop