# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 08:49:59 2019

@author: adhamlin
"""


def displayAge():
    age = 24
    print("Age in method displayAge", age)
    return


def printAge():
    age = 33
    print("Age in printAge ", age)
    return


age = 21
name = "Sarah"
printAge()
print(name, "'s age is", age)
displayAge()
printAge()
