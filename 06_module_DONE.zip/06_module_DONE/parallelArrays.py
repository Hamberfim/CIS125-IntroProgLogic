# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 18:28:49 2019

@author: adhamlin
"""
import numpy as np

INDEX_SIZE = 4
index = 0
idList = [121, 135, 172, 189]
idNumber = np.asarray(idList)
nameList = ["anne", "Bill", "Carl", "Diane"]
name = np.asarray(nameList)
foundName = "not found"

userEntry = input("Entr ID number to find associated name: ")
userEntry = int(userEntry)
while index < INDEX_SIZE and foundName == "not found":
    if userEntry == idNumber[index]:
        foundName = name[index]
    index = index + 1

print("ID #", userEntry, "is", foundName)
