# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 11:07:00 2019

@author: adhamlin
"""

import array as arr

number = input("Enter a whole number: ")
number = int(number)

# declare array by its type code/data type
# https://docs.python.org/3.7/library/array.html?highlight=array#module-array
count = arr.array('q', (0, 0, 0, 0))
while number > 0:
    if number < 4:
        count[number] = count[number] + 1
    else:
        # if any number other than 1, 2, 3 add count at index 0
        # if 0 (zero) exit while loop
        count[0] = count[0] + 1

    number = input("Enter a whole number: ")
    number = int(number)

print()  # create some space in the output
print(count)


""" ORIGINAL

import array as arr

number = input("Enter a whole number: ")
number = int(number)

# declare array by its type code/data type
# https://docs.python.org/3.7/library/array.html?highlight=array#module-array
count = arr.array('q', (0, 0, 0, 0))
while number > 0:
    if number == 1:
        count[1] = count[1] + 1
    else:
        if number == 2:
            count[2] = count[2] + 1
        else:
            if number == 3:
                count[3] = count[3] + 1
            else:  # if any number other than 1, 2, 3 add count at index 0
                   # if 0 (zero) exit while loop
                count[0] = count[0] + 1

    number = input("Enter a whole number: ")
    number = int(number)

print()  # create some space in the output
print(count)

"""

# Count Array input backwords
import numpy as np

rawNumbers = input("Enter 15 whole numbers seperated by a comma: ")
# raw user input = 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
numbers = rawNumbers.split(",")
numArray = np.asarray(numbers)

index = 14
while index >= 0:
    print(numArray[index])
    index = index - 1

"""
num INDEX_SIZE = 15
num numbers[15]
num index = 0


if index < INDEX_SIZE
    input numbers
    index = index + 1
else:
    index = 14
    while index >= 0
        output numbers[index]
        index = index - 1
    endwhile
endif
"""
INDEX_SIZE = 15
numbers = []
index = 0

if index < INDEX_SIZE:
    number = input("Enter number: ")
    number = int(number)
    numbers.append(number)
    index = index + 1
elif index == INDEX_SIZE:
    index = 15
    while index >= 0:
        print(numbers[index])
        index = index - 1
