# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 10:24:27 2019

@author: adhamlin
"""
import array as arr

number = input("Enter a whole number: ")
number = int(number)

# declare array by its type code/data type
# https://docs.python.org/3.7/library/array.html?highlight=array#module-array
count = arr.array('q', (0, 0, 0, 0))
while number > 0:
    if number == 1:
        count[1] = count[1] + 1
    else:
        if number == 2:
            count[2] = count[2] + 1
        else:
            if number == 3:
                count[3] = count[3] + 1
            else:  # if any number other than 1, 2, 3 add count at index 0
                   # if 0 (zero) exit while loop"""
                count[0] = count[0] + 1

    number = input("Enter a whole number: ")
    number = int(number)

print()  # create some space in the output
print(count)
