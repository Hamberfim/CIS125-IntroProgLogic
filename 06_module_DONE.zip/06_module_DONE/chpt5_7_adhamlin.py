# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 09:55:45 2019

@author: adhamlin
"""


lastName = []
firstName = []
employeeDeptID = []

deptNum = 1, 2, 3, 4, 5, 6, 7
deptName = "Personnel", "Marketing", "Manufacturing", "Computer Services", "Sales", "Accounting", "Shipping"
salaryPerHour = []
numHoursWorked = []
totalGrossPerDept = []

lastName = input("Enter Last Name: ")
firstName = input("Enter First Name: ")
employeeDeptID = input("Enter dept ID # (1-7):")
employeeDeptID = int(employeeDeptID)
salaryPerHour = input("Enter per hour salary: ")
salaryPerHour = float(salaryPerHour)
numHoursWorked = input("Enter number of hours worked: ")
numHoursWorked = float(numHoursWorked)
