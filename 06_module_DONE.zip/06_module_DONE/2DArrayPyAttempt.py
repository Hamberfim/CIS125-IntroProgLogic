# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 19:50:34 2019

@author: adhamlin
"""
import numpy as np

statsList = [[10, 12, 15, 9],
             [7, 3, 19, 8],
             [21, 3, 5, 9],
             [25, 42, 6, 2]]
stats = np.asarray(statsList)

getStatRow = input("Enter row: ")
getStatRow = int(getStatRow)
getStatCol = input("Enter column: ")
getStatCol = int(getStatCol)

print(stats[getStatRow][getStatCol])
