# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 2019

@author: adhamlin
"""
# 100 labels
# Declare constants
LABELS = 100
LABEL_TEXT = "Made for you personally by "
QUIT = "ZZZ"

# get user input for "makerName"
makerName = input("Enter made by name: ")
# determine whether loop executes -indefinate outer loop
while makerName != QUIT:
    # initialize loop counter control variable
    labelCounter = 0
    # determine whether loop executes -definite inner loop
    while labelCounter != LABELS:
        print(LABEL_TEXT, makerName)
        # alter loop counter control variable
        labelCounter = labelCounter + 1
    makerName = input("Enter makers name: ")
print()  # provide some space in output
print("Label printing is completed.")
