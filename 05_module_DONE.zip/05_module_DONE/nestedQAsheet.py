# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 2019

@author: adhamlin
"""
# nested loop question/answer sheet
# Declare constants
PARTS = 5
QUESTIONS = 3
PART_LABEL = "Part"
LINE = ".) _____________________"

# initialize loop counter control variable
partCounter = 1
# determine whether loop executes-loop thru top level "PARTS"
while partCounter <= PARTS:
    print(PART_LABEL, partCounter)
    # initialize loop counter control variable
    questionCounter = 1
    # determine whether loop executes-while partCounter is true loop thru "QUESTIONS"
    while questionCounter <= QUESTIONS:
        print(questionCounter, LINE)
        # alter loop counter control variable
        questionCounter = questionCounter + 1
    print()  # provide some space in output below questions for next part
    # alter loop counter control variable
    partCounter = partCounter + 1
