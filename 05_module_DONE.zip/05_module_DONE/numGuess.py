# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 2019

@author: adhamlin
"""
# import library for random int
import random

# varible range for random number
randomNumber = random.randint(1, 10)

# initilize user guess count
guessCount = 0

# get user input guess
guess = input("Guess my number between 1-10: ")

# cast user string to integer
guess = int(guess)

# loop execution
while guess != randomNumber:
    if guess > randomNumber:
        print("Your guess is to high.")
        guessCount = guessCount + 1
        guess = input("Guess again: ")
        guess = int(guess)
    elif guess < randomNumber:
        print("Your guess is too low.")
        guessCount = guessCount + 1
        guess = input("Guess again: ")
        guess = int(guess)

print("You are correct!")
guessCount = guessCount + 1
print("You guessed this many times: ", guessCount)
