# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 2019

@author: adhamlin
"""
# Count up
countUp = 1

while countUp != 11:
    print(countUp)
    countUp = countUp + 1

print("Top Floor!")

print("")  # added space between counts

# Count Down
countDown = 10

while countDown != 0:
    print(countDown)
    countDown = countDown - 1

print("Lift Off!")
