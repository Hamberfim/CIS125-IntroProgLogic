# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 2019

@author: adhamlin
"""

bankBal = input("Enter your bank balance: ")
response = input('Enter "Y" to see your bank balance: ')

bankBal = float(bankBal)
INTRATE = 0.04

while response == "Y" or response == "y":
    print("Bank balance is", round(bankBal, 3))
    bankBal = bankBal + bankBal * INTRATE
    response = input('Do you want to see next years balance plus interest? "Y" or "N" ')

print()  # provide some output space
print("OK, have a nice day!")
