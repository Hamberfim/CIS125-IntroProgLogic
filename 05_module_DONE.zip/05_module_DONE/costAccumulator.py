# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 12:38:39 2019

@author: adhamlin
"""

# Cost Accumulator
# Constants
TOTAL_ITEMS = 5

# initialize control var
itemsScanned = 0

# initialize accumulated total cost var
totalCost = 0

# determine whether loop executes
while itemsScanned < TOTAL_ITEMS:
    scannedItemCost = input("Enter scanned item cost: ")
    scannedItemCost = float(scannedItemCost)  # cast string to floating number
    totalCost = totalCost + scannedItemCost
    # alter loop control var
    itemsScanned = itemsScanned + 1
print()  # provide some space in output
print("Total cost:", totalCost)
print("Total items:", TOTAL_ITEMS)
print("Average item cost:", (totalCost / TOTAL_ITEMS))
