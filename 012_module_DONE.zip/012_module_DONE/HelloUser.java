public class HelloUser {
    public static void main(String[] args) {
        String userName = args[0];
        System.out.println("Hello " + userName + "!");
    }
}