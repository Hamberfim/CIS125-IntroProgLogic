
public class AlgorithToCode {
    public static void main(String[] args) {
        String firstName = "Anthony";
        String lastName = "Hamlin";
        String state = "Iowa";
        Number zip = 50315;
        String country = "USA";
        System.out.println("First Name: " + firstName + "." + " " + "This is my first name.");
        System.out.println("Last Name: " + lastName + "." + " " + "This is my last name.");
        System.out.println("State: " + state + "." + " " + "This is the State I live in.");
        System.out.println("Zip: " + zip + "." + " " + "This is a zipcode of an area I live in.");
        System.out.println("Country: " + country + "." + " " + "This is the country where all of the is.");
        System.out.println("...and now it is time to go to bed.");
    }
}
