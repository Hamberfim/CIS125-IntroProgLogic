
public class voidMethod {
	public static void main(String[] args) {
		printFavorite();
	  }

	  public static void printFavorite() {
	    System.out.println("Anthony Hamlin.");
	    System.out.println("A favorite Subject: Movies by Terry Gilliam and Wes Anderson");
	  }
}
