public class returnLucky {
	public static void main(String[] args) {
		// declare and initialize variables
		String myName = "Anthony Hamlin";
		int favoriteNumber = 3;

		String catVariables = myName + ", " + favoriteNumber + ".";
		System.out.println("Here is my name and favortie number: " + catVariables);
	}
}
