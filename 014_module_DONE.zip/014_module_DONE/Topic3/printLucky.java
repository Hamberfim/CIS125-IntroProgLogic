public class printLucky {
	public static void main(String[] args) {	
		printNameLucky("Anthony Hamlin", 3);
	  }
	
	public static void printNameLucky(String myName, int luckNum) {
		System.out.println(myName + ", " + luckNum);
	}
}
