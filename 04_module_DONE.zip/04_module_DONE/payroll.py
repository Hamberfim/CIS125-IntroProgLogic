# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 12:23:00 2019

@author: adhamlin
"""
# Overtime payroll program
# User input variables
name = input("Enter Name:")
hoursWorked = input("Enter Hours Worked:")
rate = input("Enter pay rate:")

# declare constants
HOURS_IN_WK = 40
OVERTIME_RATE = 1.5

# convert string input variables to floating numbers
hoursWorked = float(hoursWorked)
rate = float(rate)

# check hours for overtime and calculate individual payroll
if hoursWorked > HOURS_IN_WK:
    pay = rate * HOURS_IN_WK + (hoursWorked - HOURS_IN_WK) * OVERTIME_RATE * rate
else:
    pay = hoursWorked * rate

# output results
print("Name:", name, "Hours:", hoursWorked, "Pay:", pay)
