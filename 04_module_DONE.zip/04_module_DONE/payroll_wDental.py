# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 12:23:00 2019

@author: adhamlin
"""
# Overtime payroll program
# User input variables
name = input("Enter Name:")
hoursWorked = input("Enter Hours Worked:")
rate = input("Enter pay rate:")
dentalPlan = input('Enter "Y" if you are on the dental plan "N" if not:')

# declare constants
HOURS_IN_WK = 40
OVERTIME_RATE = 1.5
DENTAL_PREMIUM = 45.85

# convert string input variables to floating numbers
hoursWorked = float(hoursWorked)
rate = float(rate)

# check hours for overtime and calculate individual payroll
if hoursWorked > HOURS_IN_WK:
    pay = rate * HOURS_IN_WK + (hoursWorked - HOURS_IN_WK) * OVERTIME_RATE * rate
else:
    pay = hoursWorked * rate

# check if enrolled in the dental plan
if dentalPlan == "Y":
    pay = pay - DENTAL_PREMIUM

# output results
print("Name:", name, "Hours:", hoursWorked, "Pay:", pay)
