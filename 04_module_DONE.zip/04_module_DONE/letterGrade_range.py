# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 11:39:13 2019

@author: adhamlin
"""

# get user grade input
grade = input("Enter your numeric grade:")

# cast string input to integer
grade = float(grade)

# delare contants
gradeMax = 100
gradeMin_A = 90
gradeMin_B = 80
gradeMin_C = 70
gradeMin_D = 60

# test range for letter grade
if grade >= gradeMin_A and grade <= gradeMax:
    letterGrade = "A"
elif grade >= gradeMin_B and grade < gradeMin_A:
    letterGrade = "B"
elif grade >= gradeMin_C and grade < gradeMin_B:
    letterGrade = "C"
elif grade >= gradeMin_D and grade < gradeMin_C:
    letterGrade = "D"
else:
    letterGrade = "F"

print("Your letter grade is", letterGrade)
