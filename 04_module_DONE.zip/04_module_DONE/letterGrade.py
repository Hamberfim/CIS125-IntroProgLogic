# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 11:39:13 2019

@author: adhamlin
"""

# get user grade input
grade = input("Enter your whole number numeric grade:")

# cast string input to integer
grade = int(grade)

# test range for letter grade
if grade >= 90:
    letterGrade = "A"
elif grade >= 80:
    letterGrade = "B"
elif grade >= 70:
    letterGrade = "C"
elif grade >= 60:
    letterGrade = "D"
else:
    letterGrade = "F"

print("Your letter grade is", letterGrade)
